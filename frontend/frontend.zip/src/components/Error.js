import React from 'react'

const Error = () => {
  return (
    <div>Oops... Something Went Wrong</div>
  )
}

export default Error